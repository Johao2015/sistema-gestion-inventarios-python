# Sistema de Gestión de Inventarios

Proyecto desarrollado en Python utilizando Programación Orientada a Objetos.

## Funcionalidades
- Agregar productos
- Eliminar productos por ID
- Actualizar cantidad y precio
- Buscar productos por nombre
- Mostrar inventario completo

## Ejecución
Ejecutar el archivo `main.py`:
python main.py
